from django.contrib import admin
from .models import Professor, StudentSession, Match, Question


# Custom Inline for Student Sessions
class StudentSessionInline(admin.TabularInline):
    model = StudentSession
    extra = 0
    fields = ('student_uid', 'total_correct', 'total_points')
    readonly_fields = ('current_submission_time',)


# Professor Admin
class ProfessorAdmin(admin.ModelAdmin):
    list_display = ('name', 'professor_uid', 'email', 'department')
    search_fields = ('name', 'professor_uid')
    inlines = [StudentSessionInline]  # Show student sessions in professor admin
    exclude = ('user',)  # If you add user field later

    def save_model(self, request, obj, form, change):
        """Auto-assign user on save"""
        if not obj.pk:  # Only on creation
            obj.user = request.user
        super().save_model(request, obj, form, change)

    def has_add_permission(self, request):
        """Only superusers can add professors"""
        return request.user.is_superuser

    def has_change_permission(self, request, obj=None):
        """Only owners or superusers can edit"""
        if obj and (obj.user == request.user or request.user.is_superuser):
            return True
        return False


# Match Admin
class MatchAdmin(admin.ModelAdmin):
    list_display = ('professor', 'current_question_index', 'questions_count')
    list_filter = ('professor',)

    def questions_count(self, obj):
        return len(obj.questions)

    questions_count.short_description = "Total Questions"


# Question Admin
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('short_question', 'correct_index', 'answers_count')

    def short_question(self, obj):
        return obj.question[:50] + "..." if len(obj.question) > 50 else obj.question

    short_question.short_description = "Question"

    def answers_count(self, obj):
        return len(obj.answers)

    answers_count.short_description = "Answers"


# Student Session Admin
class StudentSessionAdmin(admin.ModelAdmin):
    list_display = ('student_uid', 'professor', 'total_points')
    list_filter = ('professor',)
    readonly_fields = ('current_submission_time',)


# Register all models
admin.site.register(Professor, ProfessorAdmin)
admin.site.register(StudentSession, StudentSessionAdmin)
admin.site.register(Match, MatchAdmin)
admin.site.register(Question, QuestionAdmin)
