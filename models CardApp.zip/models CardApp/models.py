from django.db import models
from django.contrib.auth.models import User

class Professor(models.Model):
    name = models.CharField(max_length=200)
    professor_uid = models.CharField(max_length=100, unique=True)  # Unique identifier for the professor
    email = models.EmailField(blank=True)  # Optional email field

    def __str__(self):
        return f"Professor {self.name} ({self.professor_uid})"

class StudentSession(models.Model):
    student_uid = models.CharField(max_length=100)  # Unique identifier for the student
    total_correct = models.IntegerField(default=0)  # Total number of correct answers
    total_points = models.IntegerField(default=0)  # Total points earned by the student
    current_submission_index = models.IntegerField(default=0)  # Index of the current submission
    current_submission_time = models.DateTimeField(null=True, blank=True)  # Time of the current submission
    professor = models.ForeignKey(Professor,on_delete=models.CASCADE,related_name='student_sessions') #one-to-many relationships

    def __str__(self):
        return f"StudentSession(student_uid={self.student_uid}, total_points={self.total_points})"

class Match(models.Model):
    students = models.JSONField()  # Stores a dictionary mapping socketId to StudentSession
    current_question_index = models.IntegerField()  # Tracks the current question index
    questions = models.JSONField()  # Stores a list of Question objects

    def __str__(self):
        return f"Match with {len(self.students)} students and {len(self.questions)} questions"

class Question(models.Model):
    question = models.CharField(max_length=500)  # Stores the question text
    correct_index = models.IntegerField()  # Index of the correct answer
    answers = models.JSONField()  # Stores a list of possible answers

    def __str__(self):
        return f"Question: {self.question} (Correct Answer Index: {self.correct_index})"
